package com.hw3.demo;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Crawler {

    private static final String AMAZON_QUERY_URL = "https://www.amazon.com/s/ref=nb_sb_noss_2?field-keywords=";

    public List<Ad> getAmazonProds(String query) throws IOException {

            String url = AMAZON_QUERY_URL + query;
            Document doc = Jsoup.connect(url).timeout(1000).get();

            Element category = doc.select("#leftNavContainer > ul:nth-child(2) > li.s-ref-indent-one > span > h4").first();
            String categoryText = "";
            if (category != null && category.hasText() == true) {
                categoryText = category.text();
            }

            List<Ad> ads = new ArrayList<>();

            Elements prods = doc.getElementsByClass("s-result-item celwidget ");
            for (Integer i = 0; i < prods.size(); i++) {
                String id = "result_" + i.toString();
                Element prodsById = doc.getElementById(id);
                String adId = prodsById.attr("data-asin");

                Elements prices = prodsById.getElementsByAttribute("aria-label");
                String price = "0.0";
                if (prices != null && prices.hasText() == true) {
                    price = prices.first().text();
                }

                String image = "";
                try{
                    image = prodsById.getElementsByClass("s-access-image cfMarker").first().attr("src");
                }
                catch (NullPointerException e) {
                    e.printStackTrace();
                }

                Elements titleAndLink = prodsById.getElementsByAttribute("title");
                String title = titleAndLink.first().attr("title");
                String link = titleAndLink.first().attr("href");


                String[] words = title.split(" ");
                int idNumber = (int)(Math.random() * 10000);
                List<String> keywords = new ArrayList<>(Arrays.asList(words));
                //double priceNumber = Double.parseDouble(price.split(" ")[1]) + Double.parseDouble(price.split(" ")[2]) / 100;
                String brand = words[0];
                String completeLink = link;
                if (link.charAt(0) != 'h') {
                    completeLink = "https://www.amazon.com" + link;
                }

                ads.add(new Ad(idNumber, keywords, title, price, image, brand, completeLink, categoryText));
            }

        return ads;
    }
}
