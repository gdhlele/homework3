package com.hw3.demo;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class Main {

    public static void main(String[] args) throws IOException {

        File file = new File("./rawQuery3.txt");
        //File file = new File("/home/vagrant/workspace/homework3/rawQuery3.txt");
        BufferedReader brIn = new BufferedReader(new FileReader(file));

        ArrayList<String> query = new ArrayList<String>();
        ArrayList<String> bidPrice = new ArrayList<String>();
        ArrayList<String> campaignId = new ArrayList<String>();
        ArrayList<String> queryGroup = new ArrayList<String>();

        String line = "";
        while ((line = brIn.readLine()) != null) {
            if (line.isEmpty()) {
                continue;
            }
            String[] temp = line.split(",");
            query.add(temp[0].trim());
            bidPrice.add(temp[1].trim());
            campaignId.add(temp[2].trim());
            queryGroup.add(temp[3].trim());
        }
        //System.out.println(query);System.out.println(bidPrice);System.out.println(campaignId);System.out.println(queryGroup);


        //List<Ad> allAds = new ArrayList<>();
        Crawler crawler = new Crawler();

        ObjectMapper mapper = new ObjectMapper();
        File outputFile = new File("./ads.json");
        //File outputFile = new File("/home/vagrant/workspace/homework3/ads.json");
        BufferedWriter brOut = new BufferedWriter(new FileWriter(outputFile));
        int counter = 0;

        for (int i = 0; i < query.size(); i++) {
            List<Ad> temp = crawler.getAmazonProds(query.get(i).replaceAll(" ", "%20"));

            for (Ad ad: temp) {
                ad.query = query.get(i);
                ad.bidPrice = Double.parseDouble(bidPrice.get(i));
                ad.campaignId = Integer.parseInt(campaignId.get(i));
                ad.query_group_id = Integer.parseInt(queryGroup.get(i));

                //allAds.add(ad);
                brOut.append(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(ad));
                brOut.newLine();
                counter++;
            }
        }

        brOut.close();

//        ObjectMapper mapper = new ObjectMapper();
//        File outputFile = new File("/home/vagrant/workspace/homework3/ads.json");
//        BufferedWriter brOut = new BufferedWriter(new FileWriter(outputFile));
//        for (Ad ad: allAds) {
//            brOut.append(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(ad));
//            brOut.newLine();
//        }
//        System.out.println("Number of Ads extracted: " + allAds.size());
        System.out.println("Number of Ads extracted: " + counter);
    }
}
